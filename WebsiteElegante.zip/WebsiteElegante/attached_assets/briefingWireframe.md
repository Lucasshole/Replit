## Briefing: "CodeQuest" - Um Playground Gamificado para Programadores

---

### 1. Visão Geral do Projeto

* **Objetivo Principal:** Criar um site experimental gamificado que motive programadores a aprender, praticar e testar suas habilidades em desafios de programação, com um foco pesado na **interação visual e feedback instantâneo**. Queremos que seja um "playground" onde a experimentação e a diversão são tão importantes quanto o aprendizado.
* **Ideia Central/Conceito:** O site será um **universo interativo** onde cada desafio é uma "missão" e cada solução é um "artefato" que contribui para a construção de algo maior dentro da interface. A gamificação será visualmente integrada à navegação e ao feedback.
* **Restrições:** Foco inicial em um conjunto limitado de linguagens/tópicos (ex: JavaScript e algoritmos básicos). Não será um IDE completo, mas sim um ambiente para pequenos trechos de código e lógica.

### 2. Público-Alvo

* **Para quem:** Programadores iniciantes a intermediários que buscam uma forma mais divertida e interativa de praticar algoritmos, estruturas de dados e conceitos de programação. Também pode atrair desenvolvedores experientes curiosos por novas interfaces e gamificação.
* **Experiência Desejada:** Queremos que o usuário sinta **curiosidade, desafio, satisfação ao resolver problemas e uma sensação de progressão e descoberta** dentro do ambiente gamificado.

### 3. Conceito e Conteúdo

* **Elementos Gamificados Chave:**
    * **"Missões" (Desafios):** Pequenos problemas de programação com descrições claras e requisitos de entrada/saída.
    * **"Energia/Vida" (Tentativas):** Limite de tentativas para resolver um desafio, que pode ser restaurado com o tempo ou outras ações.
    * **"Recompensas Visuais":** Ao concluir um desafio, o usuário "desbloqueia" ou "constrói" um componente visual na interface principal (ex: uma torre em um cenário, uma parte de um grafo complexo, um planeta em um sistema solar).
    * **"Progresso no Mapa/Universo":** Um mapa interativo que mostra os desafios disponíveis, os concluídos e o caminho de progresso.
    * **"Badges/Conquistas":** Para marcos específicos (ex: 5 desafios resolvidos, primeiro desafio difícil).
    * **"Pontos de Experiência (XP)":** Ganhos por desafios resolvidos, talvez por tempo otimizado ou código eficiente.
* **Funcionalidades Experimentais:**
    * **Editor de Código Minimalista e Interativo:** Com realce de sintaxe e feedback visual imediato para erros ou sucesso.
    * **Visualização Dinâmica de Dados/Algoritmos:** Enquanto o código roda (ou após), uma representação visual do que está acontecendo (ex: array sendo ordenado, busca em árvore).
    * **Interface de Navegação "Não-Linear":** Em vez de menus tradicionais, talvez um sistema de "portais", "caminhos" ou "órbita" entre os desafios.
    * **Áudio Ambiental e Feedbacks Sonoros:** Sons suaves para a interface, e sons específicos para sucesso/falha do código.
* **Conteúdo Inicial:** Desafios de lógica (ex: FizzBuzz, palíndromos, fatorial), manipulação de arrays/strings.

### 4. Requisitos Técnicos e Tecnológicos

* **Frontend:**
    * **Framework:** React ou Svelte (para reatividade e performance em interações).
    * **Gráficos/Animações:** Three.js (para 3D no mapa/universo e visualização de dados), GSAP (para animações de interface e transições suaves).
    * **Estilização:** CSS-in-JS (Styled Components/Emotion) ou Tailwind CSS para flexibilidade e customização.
    * **Editor de Código:** Monaco Editor (base do VS Code) para uma experiência rica.
    * **Áudio:** Web Audio API ou bibliotecas como Howler.js.
* **Backend (Minimalista):**
    * Node.js com Express para servir os desafios e talvez validar soluções (inicialmente validação no frontend, mas no futuro no backend para segurança).
    * Database (Opcional para persistência de progresso): Firebase Firestore ou Supabase para uma configuração rápida.
* **Hospedagem:** Vercel ou Netlify para o frontend, Heroku ou Railway para o backend (se necessário).
* **Compatibilidade:** Navegadores modernos (Chrome, Firefox, Edge, Safari).

### 5. Design e Experiência do Usuário (UX/UI)

* **Estética:** "Sci-fi Minimalista" ou "Cyberpunk Leve". Cores vibrantes (neon) sobre fundos escuros/neutros. Tipografia limpa e moderna.
* **Interações Inovadoras:**
    * **Navegação por Movimento:** O mapa pode ser explorado arrastando, dando zoom.
    * **Feedback Visual Imersivo:** Erros no código causam "glitch" na tela; acertos fazem elementos visuais "florescerem".
    * **Transições Fluidas:** Sem recarregamento de página. Tudo é uma transição suave entre estados.
* **Evitar:** Menus tradicionais, pop-ups excessivos, sobrecarga de informações, estética "corporativa".

### 6. Métricas de Sucesso

* **Engajamento:** Tempo médio de sessão, número de desafios tentados e resolvidos.
* **Retenção:** Usuários retornando para novos desafios.
* **Feedback Qualitativo:** Depoimentos sobre a experiência gamificada e as visualizações.
* **Desempenho:** Fluidez das animações e tempo de carregamento.

### 7. Próximos Passos e Entregáveis

* **Fase 1 (MVP - Mínimo Produto Viável):**
    * **Wireframe Conceitual/Interativo** (ver abaixo).
    * **Protótipo de uma única "Missão"** com editor de código e visualização de dados.
    * **Estrutura básica do "Mapa/Universo"** com um ou dois desafios posicionados.
* **Prazo Estimado (MVP):** 2-4 semanas.
* **Pontos de Contato:** Desenvolvedor(a) principal, designer (se houver).

---

## Wireframe: "CodeQuest" - Aplicação Gamificada

---

Este wireframe será mais focado na **interação e nos estados da gamificação**, seguindo a abordagem conceitual.

### 1. Wireframe: Tela de Boas-Vindas / Introdução

```
+--------------------------------------------------------------------------------------------------+
| [ Cenário Imersivo Animado - Sons Ambientais ]                                                   |
| ------------------------------------------------------------------------------------------------ |
|  - Logotipo "CodeQuest" (Efeito de brilho/pulsação)                                              |
|  - Subtítulo: "Sua Jornada Pela Lógica e Criatividade"                                           |
|  - Breve Animação de Partículas/Linhas de Código Flutuando                                       |
|                                                                                                  |
|  - CTA Principal: [ BOTÃO: "INICIAR JORNADA" ] (Com feedback visual ao passar o mouse)           |
|                                                                                                  |
|  - Link "Sobre" (Ícone discreto no canto, talvez um "i" estilizado)                              |
|                                                                                                  |
+--------------------------------------------------------------------------------------------------+
```
---

### 2. Wireframe: "Universo de Missões" (Página Principal/Mapa)

```
+--------------------------------------------------------------------------------------------------+
| [ MAPA INTERATIVO / CENÁRIO 3D ]                                                                 |
| ------------------------------------------------------------------------------------------------ |
|  - **VISUAL:** Um "universo" 3D (estilo isométrico ou vista de cima) com "planetas" ou "ilhas"   |
|    representando grupos de missões/tópicos (ex: "Ilha dos Arrays", "Planeta da Recursão").       |
|    Caminhos brilhantes conectam as missões.                                                      |
|                                                                                                  |
|  - **ELEMENTOS INTERATIVOS:** |
|    - **Navegação:** Arrastar para mover o mapa, Scroll para zoom.                                |
|    - **Ícones de Missão:** Pequenos marcadores em cada "planeta/ilha" que brilham.               |
|      - Missões Concluídas: Cor diferente, talvez um "monumento" visual construído.               |
|      - Missões Ativas: Brilham, talvez com um ícone de exclamação.                               |
|      - Missões Bloqueadas: Escurecidas, com um ícone de cadeado.                                 |
|                                                                                                  |
|  - **UI MINIMALISTA (Overlay):** |
|    - **Top Bar (Horizontal, talvez translúcida):** |
|      - Ícone de "Voltar ao Início" (home)                                                        |
|      - **Contador de XP:** "XP: 1250" (com animação de aumento)                                  |
|      - **Barra de "Energia/Vida":** Representação visual (ex: 3 corações, barra de energia)      |
|      - **Avatar/Nome do Usuário** (se houver login)                                              |
|      - Ícone de "Configurações" / "Sons"                                                         |
|    - **Pop-up de Missão (ao clicar em um ícone):** |
|      - Título da Missão: "Desafio do Palíndromo"                                                 |
|      - Breve Descrição: "Verifique se a string é um palíndromo."                                 |
|      - Dificuldade: Estrelas / Nível                                                             |
|      - Recompensa Visual: Miniatura do "artefato" a ser desbloqueado.                            |
|      - [ BOTÃO: "INICIAR MISSÃO" ]                                                               |
+--------------------------------------------------------------------------------------------------+
```
---

### 3. Wireframe: "Câmara de Missão" (Editor de Código / Visualização)

```
+--------------------------------------------------------------------------------------------------+
| [ CÂMARA DE MISSÃO - Visão de Edição e Execução ]                                                |
| ------------------------------------------------------------------------------------------------ |
|  - **HEADER DA MISSÃO (Superior):** |
|    - Título da Missão: "Desafio do Palíndromo"                                                   |
|    - [ Ícone de "Voltar ao Mapa" ]                                                               |
|    - Contador de Tentativas Restantes: (Ex: "3/3 Vidas")                                         |
|                                                                                                  |
|  - **PAINEL ESQUERDO (Instruções):** |
|    - **Descrição Detalhada:** |
|      - Enunciado do problema: "Escreva uma função `isPalindrome(str)` que..."                    |
|      - Exemplos de Entrada/Saída: `isPalindrome("arara") -> true`                                |
|      - Restrições: (Ex: "Não use métodos built-in como `reverse()`.")                            |
|    - **Seção de Dicas (Opcional, com timer ou custo de "XP"):** |
|      - [ BOTÃO: "Obter Dica" ]                                                                   |
|                                                                                                  |
|  - **PAINEL CENTRAL (Editor de Código):** |
|    - **Editor de Código:** (Monaco Editor com realce de sintaxe)                                 |
|      - Área para escrever a função:                                                              |
|        ```javascript                                                                             |
|        function isPalindrome(str) {                                                              |
|          // Seu código aqui                                                                      |
|        }                                                                                         |
|        ```                                                                                       |
|    - **Botões de Ação:** |
|      - [ BOTÃO: "EXECUTAR TESTES" ] (Animação de carregamento ao clicar)                         |
|      - [ BOTÃO: "REINICIAR CÓDIGO" ]                                                             |
|                                                                                                  |
|  - **PAINEL DIREITO (Feedback/Visualização):** |
|    - **Área de Console/Saída dos Testes:** |
|      - "Testes..." (durante execução)                                                            |
|      - **Em Sucesso:** "✅ Todos os testes passaram! Missão Concluída!" (Animação de brilho, som de sucesso)
|      - **Em Falha:** "❌ Falha nos testes: Teste 1 falhou. Esperado: true, Recebido: false."     |
|        (Visualização de "glitch" na tela, som de erro)                                            
|    - **ÁREA DE VISUALIZAÇÃO DINÂMICA (Experimental):** |
|      - Se o algoritmo for visualizável (ex: ordenação), um canvas onde o array/estrutura         |
|        é animado em tempo real ou após a execução.                                               |
|      - Para um palíndromo, talvez uma visualização das comparações de caracteres.                |
+--------------------------------------------------------------------------------------------------+
```
---

### 4. Wireframe: Pop-up de Missão Concluída / Recompensa

```
+--------------------------------------------------------------------------------------------------+
| [ POP-UP: MISSÃO CONCLUÍDA! ]                                                                    |
| ------------------------------------------------------------------------------------------------ |
|  - Título Grande: "MISSÃO CONCLUÍDA!"                                                            |
|  - Animação de Partículas / Brilho                                                               |
|  - Ícone do Artefato Desbloqueado: (Ex: Imagem do "Farol da Lógica" que aparece no mapa)         |
|  - Mensagem: "Você construiu o [Nome do Artefato] e ganhou +[XP] XP!"                            |
|                                                                                                  |
|  - **Opções:** |
|    - [ BOTÃO: "CONTINUAR JORNADA" ] (Volta para o Mapa, com o artefato agora visível)            |
|    - [ BOTÃO: "REVISAR CÓDIGO" ]                                                                 |
|    - [ BOTÃO: "COMPARTILHAR CONQUISTA" ]                                                         |
+--------------------------------------------------------------------------------------------------+
```

---

### Observações Finais:

* **Progressão Visual:** A ideia é que a interface principal ("Universo de Missões") **mude e cresça** à medida que o programador avança. Elementos que estavam cinzentos ou bloqueados ganham cor e vida, novas áreas do mapa são reveladas, e os artefatos se materializam.
* **Feedback Constante:** Cada ação, acerto ou erro, deve ter um feedback visual e/ou sonoro distinto para reforçar a gamificação.
* **Flexibilidade:** Lembre-se, é um site experimental. Este é um ponto de partida. Esteja aberto a mudar as interações, a estética e até o conceito de gamificação conforme você o constrói e testa!
