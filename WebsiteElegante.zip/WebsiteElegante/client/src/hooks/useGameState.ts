import { useQuery } from "@tanstack/react-query";

interface UserStats {
  xp: number;
  energy: number;
  completedMissions: string[];
  badges: string[];
}

export const useGameState = () => {
  const { data: userStats, refetch: refreshUserStats, isLoading } = useQuery<UserStats>({
    queryKey: ["/api/user/stats"],
    staleTime: 30000, // 30 seconds
  });

  const defaultStats: UserStats = {
    xp: 0,
    energy: 3,
    completedMissions: [],
    badges: []
  };

  return {
    userStats: userStats || defaultStats,
    refreshUserStats,
    isLoading
  };
};
