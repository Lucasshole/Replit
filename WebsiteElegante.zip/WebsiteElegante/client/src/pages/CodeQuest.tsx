import { useState } from "react";
import WelcomeScreen from "@/components/WelcomeScreen";
import UniverseMap from "@/components/UniverseMap";
import MissionChamber from "@/components/MissionChamber";
import TopNavBar from "@/components/TopNavBar";
import NotificationSystem from "@/components/NotificationSystem";
import { useGameState } from "@/hooks/useGameState";

export type GameScreen = 'welcome' | 'universe' | 'mission';

export default function CodeQuest() {
  const [currentScreen, setCurrentScreen] = useState<GameScreen>('welcome');
  const [currentMissionSlug, setCurrentMissionSlug] = useState<string | null>(null);
  const gameState = useGameState();

  const handleStartJourney = () => {
    setCurrentScreen('universe');
  };

  const handleReturnToWelcome = () => {
    setCurrentScreen('welcome');
  };

  const handleOpenMission = (missionSlug: string) => {
    setCurrentMissionSlug(missionSlug);
    setCurrentScreen('mission');
  };

  const handleReturnToUniverse = () => {
    setCurrentScreen('universe');
    setCurrentMissionSlug(null);
  };

  return (
    <div className="min-h-screen particle-bg">
      <NotificationSystem />
      
      {currentScreen === 'welcome' && (
        <WelcomeScreen onStartJourney={handleStartJourney} />
      )}

      {currentScreen !== 'welcome' && (
        <>
          <TopNavBar
            userStats={gameState.userStats}
            onReturnToWelcome={handleReturnToWelcome}
          />
          
          {currentScreen === 'universe' && (
            <UniverseMap 
              onOpenMission={handleOpenMission}
              userStats={gameState.userStats}
            />
          )}
          
          {currentScreen === 'mission' && currentMissionSlug && (
            <MissionChamber
              missionSlug={currentMissionSlug}
              onReturnToUniverse={handleReturnToUniverse}
              onMissionComplete={gameState.refreshUserStats}
            />
          )}
        </>
      )}
    </div>
  );
}
