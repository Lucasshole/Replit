export interface Mission {
  id: number;
  slug: string;
  title: string;
  description: string;
  difficulty: number;
  xpReward: number;
  category: string;
  instructions: string;
  examples: { input: string; output: string }[];
  restrictions: string[];
  starterCode: string;
  tests: { input: any; expected: any }[];
  isUnlocked: boolean;
}

export interface MissionProgress {
  id: number;
  userId: number;
  missionSlug: string;
  completed: boolean;
  attempts: number;
  bestTime?: number;
  lastCode?: string;
}

export interface UserStats {
  xp: number;
  energy: number;
  completedMissions: string[];
  badges: string[];
}

export const MISSION_CATEGORIES = {
  arrays: {
    title: "Ilha dos Arrays",
    description: "Domine a manipulação de arrays e estruturas de dados básicas.",
    color: "neon-blue",
    icon: "fa-list"
  },
  recursion: {
    title: "Planeta da Recursão",
    description: "Explore os mistérios das funções recursivas e chamadas aninhadas.",
    color: "neon-green",
    icon: "fa-sync-alt"
  },
  algorithms: {
    title: "Estação dos Algoritmos",
    description: "Algoritmos avançados de busca, ordenação e otimização.",
    color: "neon-pink",
    icon: "fa-brain"
  }
};

export const DIFFICULTY_LEVELS = {
  1: { name: "Iniciante", color: "green" },
  2: { name: "Intermediário", color: "yellow" },
  3: { name: "Avançado", color: "orange" },
  4: { name: "Expert", color: "red" },
  5: { name: "Mestre", color: "purple" }
};

export const BADGES = {
  FIRST_SUCCESS: {
    id: "first_success",
    title: "Primeiro Sucesso",
    description: "Complete sua primeira missão",
    icon: "fa-trophy",
    color: "cyber-gold"
  },
  ARRAY_MASTER: {
    id: "array_master",
    title: "Mestre dos Arrays",
    description: "Complete todas as missões de arrays",
    icon: "fa-code",
    color: "neon-green"
  },
  SPEED_DEMON: {
    id: "speed_demon",
    title: "Velocidade da Luz",
    description: "Complete uma missão em menos de 2 minutos",
    icon: "fa-lightning-bolt",
    color: "neon-pink"
  },
  RECURSIVE_THINKER: {
    id: "recursive_thinker",
    title: "Pensador Recursivo",
    description: "Complete todas as missões de recursão",
    icon: "fa-brain",
    color: "neon-blue"
  }
};

// Utility functions
export const getMissionById = (missions: Mission[], id: number): Mission | undefined => {
  return missions.find(mission => mission.id === id);
};

export const getMissionBySlug = (missions: Mission[], slug: string): Mission | undefined => {
  return missions.find(mission => mission.slug === slug);
};

export const getMissionsByCategory = (missions: Mission[], category: string): Mission[] => {
  return missions.filter(mission => mission.category === category);
};

export const calculateCategoryProgress = (missions: Mission[], completedMissions: string[]): number => {
  if (missions.length === 0) return 0;
  const completed = missions.filter(mission => completedMissions.includes(mission.slug)).length;
  return Math.round((completed / missions.length) * 100);
};

export const isUserEligibleForBadge = (badge: string, userStats: UserStats, missions: Mission[]): boolean => {
  switch (badge) {
    case BADGES.FIRST_SUCCESS.id:
      return userStats.completedMissions.length > 0;
    
    case BADGES.ARRAY_MASTER.id: {
      const arrayMissions = getMissionsByCategory(missions, 'arrays');
      return arrayMissions.every(mission => userStats.completedMissions.includes(mission.slug));
    }
    
    case BADGES.RECURSIVE_THINKER.id: {
      const recursionMissions = getMissionsByCategory(missions, 'recursion');
      return recursionMissions.every(mission => userStats.completedMissions.includes(mission.slug));
    }
    
    default:
      return false;
  }
};
