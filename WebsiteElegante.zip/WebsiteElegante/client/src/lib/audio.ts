// Audio context for web audio API
let audioContext: AudioContext | null = null;

// Initialize audio context
const getAudioContext = (): AudioContext => {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioContext;
};

// Generate a tone with specific frequency and duration
const createTone = (frequency: number, duration: number, type: OscillatorType = 'sine'): void => {
  try {
    const ctx = getAudioContext();
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    oscillator.frequency.setValueAtTime(frequency, ctx.currentTime);
    oscillator.type = type;
    
    gainNode.gain.setValueAtTime(0.1, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);
    
    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + duration);
  } catch (error) {
    console.warn('Audio context not available:', error);
  }
};

// Play success sound - ascending chord
export const playSuccessSound = (): void => {
  const notes = [261.63, 329.63, 392.00, 523.25]; // C4, E4, G4, C5
  notes.forEach((frequency, index) => {
    setTimeout(() => {
      createTone(frequency, 0.2, 'triangle');
    }, index * 100);
  });
};

// Play error sound - descending dissonant tones
export const playErrorSound = (): void => {
  const notes = [440, 415, 392, 370]; // A4 to slightly flat G4
  notes.forEach((frequency, index) => {
    setTimeout(() => {
      createTone(frequency, 0.15, 'sawtooth');
    }, index * 80);
  });
};

// Play hint sound - gentle notification
export const playHintSound = (): void => {
  createTone(523.25, 0.3, 'sine'); // C5
  setTimeout(() => {
    createTone(659.25, 0.3, 'sine'); // E5
  }, 150);
};

// Play navigation sound - soft blip
export const playNavigationSound = (): void => {
  createTone(880, 0.1, 'sine'); // A5
};

// Play ambient background sound (looped)
export const playAmbientSound = (): void => {
  // This would be more complex in a real implementation
  // For now, just play a very subtle low frequency tone
  try {
    const ctx = getAudioContext();
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    
    oscillator.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    oscillator.frequency.setValueAtTime(55, ctx.currentTime); // A1
    oscillator.type = 'sine';
    
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(200, ctx.currentTime);
    
    gainNode.gain.setValueAtTime(0.02, ctx.currentTime); // Very quiet
    
    oscillator.start();
    
    // Stop after 10 seconds
    setTimeout(() => {
      oscillator.stop();
    }, 10000);
  } catch (error) {
    console.warn('Ambient audio not available:', error);
  }
};

// Initialize audio on first user interaction
export const initializeAudio = (): void => {
  const handleFirstInteraction = () => {
    getAudioContext();
    document.removeEventListener('click', handleFirstInteraction);
    document.removeEventListener('keydown', handleFirstInteraction);
  };
  
  document.addEventListener('click', handleFirstInteraction);
  document.addEventListener('keydown', handleFirstInteraction);
};

// Auto-initialize when module loads
initializeAudio();
