import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { playSuccessSound, playErrorSound, playHintSound } from "@/lib/audio";

interface MissionChamberProps {
  missionSlug: string;
  onReturnToUniverse: () => void;
  onMissionComplete: () => void;
}

export default function MissionChamber({ missionSlug, onReturnToUniverse, onMissionComplete }: MissionChamberProps) {
  const [code, setCode] = useState("");
  const [executionResults, setExecutionResults] = useState<any>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: mission, isLoading } = useQuery({
    queryKey: [`/api/missions/${missionSlug}`],
  });

  const { data: progress } = useQuery({
    queryKey: [`/api/progress/${missionSlug}`],
  });

  const executeMutation = useMutation({
    mutationFn: async ({ code }: { code: string }) => {
      const response = await apiRequest("POST", `/api/missions/${missionSlug}/execute`, { code });
      return response.json();
    },
    onSuccess: (data) => {
      setExecutionResults(data);
      if (data.success) {
        playSuccessSound();
        toast({
          title: "✨ Código executado com sucesso!",
          description: `+${mission?.xpReward || 0} XP`,
          variant: "default",
        });
        // Update progress and complete mission
        updateProgressMutation.mutate({
          missionSlug,
          completed: true,
          lastCode: code,
          attempts: (progress?.attempts || 0) + 1,
        });
      } else {
        playErrorSound();
        toast({
          title: "❌ Erro no código",
          description: "Verifique os testes e tente novamente!",
          variant: "destructive",
        });
        updateProgressMutation.mutate({
          missionSlug,
          lastCode: code,
          attempts: (progress?.attempts || 0) + 1,
        });
      }
    },
    onError: () => {
      playErrorSound();
      toast({
        title: "Erro na execução",
        description: "Houve um problema ao executar o código.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsExecuting(false);
    },
  });

  const updateProgressMutation = useMutation({
    mutationFn: async (progressData: any) => {
      const response = await apiRequest("POST", "/api/progress", progressData);
      return response.json();
    },
    onSuccess: (data) => {
      if (data.completed) {
        onMissionComplete();
      }
      queryClient.invalidateQueries({ queryKey: [`/api/progress/${missionSlug}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/stats"] });
    },
  });

  useEffect(() => {
    if (mission?.starterCode) {
      setCode(mission.starterCode);
    }
  }, [mission]);

  useEffect(() => {
    if (progress?.lastCode && !code.trim()) {
      setCode(progress.lastCode);
    }
  }, [progress, code]);

  const handleRunCode = () => {
    if (!code.trim()) {
      toast({
        title: "Código vazio",
        description: "Escreva algum código antes de executar!",
        variant: "destructive",
      });
      return;
    }

    setIsExecuting(true);
    executeMutation.mutate({ code });
  };

  const handleResetCode = () => {
    if (mission?.starterCode) {
      setCode(mission.starterCode);
      setExecutionResults(null);
      toast({
        title: "Código resetado!",
        description: "O código foi restaurado para o estado inicial.",
      });
    }
  };

  const handleShowHint = () => {
    playHintSound();
    toast({
      title: "💡 Dica",
      description: "Use dois ponteiros, um no início e outro no fim da string!",
      duration: 5000,
    });
  };

  if (isLoading) {
    return (
      <div className="pt-24 pb-8 px-8 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <Skeleton className="h-24 w-full mb-8 rounded-2xl" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Skeleton className="h-96 rounded-2xl" />
            <Skeleton className="h-96 rounded-2xl" />
            <Skeleton className="h-96 rounded-2xl" />
          </div>
        </div>
      </div>
    );
  }

  if (!mission) {
    return (
      <div className="pt-24 pb-8 px-8 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Missão não encontrada</h2>
          <button onClick={onReturnToUniverse} className="btn-primary px-6 py-3 rounded-lg">
            Voltar ao Universo
          </button>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="pt-24 pb-8 px-8 min-h-screen"
    >
      <div className="max-w-7xl mx-auto">
        {/* Mission Header */}
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.6 }}
          className="floating-ui rounded-2xl p-6 mb-8"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={onReturnToUniverse}
                className="text-neon-blue hover:text-white transition-colors"
              >
                <i className="fas fa-arrow-left text-xl"></i>
              </button>
              <div>
                <h2 className="font-orbitron font-bold text-2xl text-neon-blue">{mission.title}</h2>
                <div className="flex items-center space-x-4 mt-2">
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <i
                        key={i}
                        className={`fas fa-star ${
                          i < mission.difficulty ? 'text-cyber-gold' : 'text-gray-400'
                        }`}
                      />
                    ))}
                    <span className="text-sm text-gray-400 ml-2">
                      {mission.difficulty === 1 ? 'Iniciante' :
                       mission.difficulty === 2 ? 'Intermediário' :
                       mission.difficulty === 3 ? 'Avançado' :
                       mission.difficulty === 4 ? 'Expert' : 'Mestre'}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-400">Tentativas:</span>
                    <span className="text-sm">{progress?.attempts || 0}</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-cyber-gold font-bold text-lg">+{mission.xpReward} XP</div>
              <div className="text-sm text-gray-400">Recompensa</div>
            </div>
          </div>
        </motion.div>
        
        {/* Mission Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Panel - Instructions */}
          <motion.div
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="lg:col-span-1"
          >
            <div className="floating-ui rounded-2xl p-6 h-full">
              <h3 className="font-orbitron font-bold text-lg mb-4 text-neon-green">Instruções da Missão</h3>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-white mb-2">Descrição:</h4>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    {mission.instructions}
                  </p>
                </div>
                
                <div>
                  <h4 className="font-semibold text-white mb-2">Exemplos:</h4>
                  <div className="font-mono text-sm space-y-1 bg-dark-navy p-3 rounded-lg">
                    {mission.examples.map((example: any, index: number) => (
                      <div key={index}>
                        <span className="text-neon-green">input</span>: <span className="text-cyber-gold">{example.input}</span> → <span className="text-neon-blue">{example.output}</span>
                      </div>
                    ))}
                  </div>
                </div>
                
                {mission.restrictions && mission.restrictions.length > 0 && (
                  <div>
                    <h4 className="font-semibold text-white mb-2">Restrições:</h4>
                    <ul className="text-gray-300 text-sm space-y-1">
                      {mission.restrictions.map((restriction: string, index: number) => (
                        <li key={index}>• {restriction}</li>
                      ))}
                    </ul>
                  </div>
                )}
                
                <button
                  onClick={handleShowHint}
                  className="btn-primary w-full py-3 rounded-lg font-semibold mt-6"
                >
                  <i className="fas fa-lightbulb mr-2"></i>
                  Obter Dica (-50 XP)
                </button>
              </div>
            </div>
          </motion.div>
          
          {/* Center Panel - Code Editor */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
            className="lg:col-span-1"
          >
            <div className="floating-ui rounded-2xl p-6 h-full">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-orbitron font-bold text-lg text-neon-green">Editor de Código</h3>
                <div className="flex space-x-2">
                  <button
                    onClick={handleRunCode}
                    disabled={isExecuting}
                    className="btn-primary px-4 py-2 rounded-lg text-sm disabled:opacity-50"
                  >
                    <i className={`fas ${isExecuting ? 'fa-spinner fa-spin' : 'fa-play'} mr-1`}></i>
                    {isExecuting ? 'EXECUTANDO...' : 'EXECUTAR'}
                  </button>
                  <button
                    onClick={handleResetCode}
                    className="bg-gray-600 hover:bg-gray-500 px-4 py-2 rounded-lg text-sm transition-colors"
                  >
                    <i className="fas fa-undo mr-1"></i>
                    RESET
                  </button>
                </div>
              </div>
              
              {/* Code Editor Area */}
              <div className="code-editor rounded-lg p-4 h-96">
                <textarea
                  ref={textareaRef}
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="w-full h-full bg-transparent text-gray-100 font-mono text-sm resize-none outline-none"
                  placeholder="// Escreva seu código aqui..."
                  spellCheck={false}
                />
              </div>
            </div>
          </motion.div>
          
          {/* Right Panel - Feedback & Visualization */}
          <motion.div
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="lg:col-span-1"
          >
            <div className="floating-ui rounded-2xl p-6 h-full">
              <h3 className="font-orbitron font-bold text-lg mb-4 text-neon-pink">Console & Visualização</h3>
              
              <div className="space-y-4">
                {/* Test Results */}
                <div className="bg-dark-navy rounded-lg p-4">
                  <h4 className="font-semibold text-white mb-2">Resultados dos Testes:</h4>
                  <div className="space-y-2 font-mono text-sm">
                    {executionResults ? (
                      executionResults.tests.map((test: any, index: number) => (
                        <div key={index} className="flex items-center space-x-2">
                          <i className={`fas ${test.passed ? 'fa-check text-green-400' : 'fa-times text-red-400'}`}></i>
                          <span className="text-gray-300">
                            Test {index + 1}: input({JSON.stringify(test.input)})
                          </span>
                          {!test.passed && (
                            <div className="text-red-400 text-xs ml-6">
                              Expected: {JSON.stringify(test.expected)}, Got: {JSON.stringify(test.actual)}
                            </div>
                          )}
                        </div>
                      ))
                    ) : (
                      mission.tests.map((_: any, index: number) => (
                        <div key={index} className="flex items-center space-x-2">
                          <i className="fas fa-clock text-yellow-400"></i>
                          <span className="text-gray-300">Test {index + 1}: Aguardando execução...</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
                
                {/* Algorithm Visualization */}
                <div className="bg-dark-navy rounded-lg p-4">
                  <h4 className="font-semibold text-white mb-2">Visualização:</h4>
                  <div className="text-center py-8">
                    <div className="text-gray-500 mb-4">
                      <i className="fas fa-eye text-3xl"></i>
                    </div>
                    <p className="text-gray-400 text-sm">
                      {executionResults ? 'Algoritmo executado com sucesso!' : 'Execute o código para ver a visualização do algoritmo em ação'}
                    </p>
                  </div>
                </div>
                
                {/* Performance Metrics */}
                <div className="bg-dark-navy rounded-lg p-4">
                  <h4 className="font-semibold text-white mb-2">Performance:</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Tempo de execução:</span>
                      <span className="text-gray-300">
                        {executionResults?.executionTime ? `${executionResults.executionTime} ms` : '-- ms'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Complexidade:</span>
                      <span className="text-gray-300">
                        {executionResults?.complexity || 'O(?)'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}
