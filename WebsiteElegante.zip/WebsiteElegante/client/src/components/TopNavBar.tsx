import { motion } from "framer-motion";

interface UserStats {
  xp: number;
  energy: number;
  completedMissions: string[];
  badges: string[];
}

interface TopNavBarProps {
  userStats: UserStats;
  onReturnToWelcome: () => void;
}

export default function TopNavBar({ userStats, onReturnToWelcome }: TopNavBarProps) {
  return (
    <motion.nav
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="floating-ui fixed top-4 left-4 right-4 z-40 rounded-2xl px-6 py-4"
    >
      <div className="flex items-center justify-between">
        {/* Left Section */}
        <div className="flex items-center space-x-6">
          <button
            onClick={onReturnToWelcome}
            className="text-neon-blue hover:text-white transition-colors"
          >
            <i className="fas fa-home text-xl"></i>
          </button>
          <div className="font-orbitron font-bold text-xl neon-text">CodeQuest</div>
        </div>
        
        {/* Center Section - User Stats */}
        <div className="flex items-center space-x-8">
          {/* XP Counter */}
          <div className="flex items-center space-x-2">
            <i className="fas fa-star text-cyber-gold"></i>
            <span className="font-mono font-semibold">XP: {userStats.xp.toLocaleString()}</span>
          </div>
          
          {/* Energy/Lives */}
          <div className="flex items-center space-x-2">
            <div className="flex space-x-1">
              {[...Array(3)].map((_, index) => (
                <div
                  key={index}
                  className={`energy-orb ${index >= userStats.energy ? 'opacity-30' : ''}`}
                />
              ))}
            </div>
            <span className="text-sm text-gray-400">{userStats.energy}/3</span>
          </div>
        </div>
        
        {/* Right Section */}
        <div className="flex items-center space-x-4">
          {/* User Avatar */}
          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-neon-blue to-neon-green flex items-center justify-center">
            <i className="fas fa-user text-dark-navy"></i>
          </div>
          
          {/* Settings */}
          <button className="text-gray-400 hover:text-neon-blue transition-colors">
            <i className="fas fa-cog text-xl"></i>
          </button>
        </div>
      </div>
    </motion.nav>
  );
}
