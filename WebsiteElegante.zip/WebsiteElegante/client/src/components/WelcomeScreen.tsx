import { motion } from "framer-motion";

interface WelcomeScreenProps {
  onStartJourney: () => void;
}

export default function WelcomeScreen({ onStartJourney }: WelcomeScreenProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, y: -100 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 z-50 flex items-center justify-center particle-bg"
    >
      <div className="text-center space-y-8 max-w-2xl px-6">
        {/* CodeQuest Logo */}
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="space-y-4"
        >
          <h1 className="font-orbitron font-black text-6xl md:text-8xl neon-text animate-pulse-glow">
            CODE<span className="text-neon-green">QUEST</span>
          </h1>
          <p className="font-inter text-xl md:text-2xl text-gray-300 animate-glow">
            Sua Jornada Pela Lógica e Criatividade
          </p>
        </motion.div>
        
        {/* Floating Code Particles Animation */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="relative h-32 overflow-hidden"
        >
          <div className="absolute inset-0 flex items-center justify-center space-x-4 animate-float">
            <span className="font-mono text-neon-blue opacity-70 text-2xl">{"{"}</span>
            <span className="font-mono text-neon-green opacity-70 text-xl">function()</span>
            <span className="font-mono text-neon-pink opacity-70 text-2xl">=&gt;</span>
            <span className="font-mono text-cyber-gold opacity-70 text-xl">adventure</span>
            <span className="font-mono text-neon-blue opacity-70 text-2xl">{"}"}</span>
          </div>
        </motion.div>
        
        {/* CTA Button */}
        <motion.button
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onStartJourney}
          className="btn-primary px-12 py-4 rounded-xl font-orbitron text-xl font-bold tracking-wider transition-transform duration-300 relative z-10 cursor-pointer"
        >
          INICIAR JORNADA
        </motion.button>
        
        {/* About Link */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="absolute bottom-8 right-8"
        >
          <button className="text-gray-400 hover:text-neon-blue transition-colors duration-300">
            <i className="fas fa-info-circle text-2xl"></i>
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
}
