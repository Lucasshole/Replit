import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import ThreeScene from "./ThreeScene";
import { Skeleton } from "@/components/ui/skeleton";

interface UserStats {
  xp: number;
  energy: number;
  completedMissions: string[];
  badges: string[];
}

interface UniverseMapProps {
  onOpenMission: (missionSlug: string) => void;
  userStats: UserStats;
}

interface MissionGroup {
  category: string;
  title: string;
  description: string;
  missions: any[];
  color: string;
  icon: string;
}

export default function UniverseMap({ onOpenMission, userStats }: UniverseMapProps) {
  const { data: missions, isLoading } = useQuery({
    queryKey: ["/api/missions"],
  });

  const missionGroups: MissionGroup[] = [
    {
      category: "arrays",
      title: "Ilha dos Arrays",
      description: "Domine a manipulação de arrays e estruturas de dados básicas.",
      missions: missions?.filter((m: any) => m.category === "arrays") || [],
      color: "neon-blue",
      icon: "fa-list"
    },
    {
      category: "recursion",
      title: "Planeta da Recursão",
      description: "Explore os mistérios das funções recursivas e chamadas aninhadas.",
      missions: missions?.filter((m: any) => m.category === "recursion") || [],
      color: "neon-green",
      icon: "fa-sync-alt"
    },
    {
      category: "algorithms",
      title: "Estação dos Algoritmos",
      description: "Algoritmos avançados de busca, ordenação e otimização.",
      missions: missions?.filter((m: any) => m.category === "algorithms") || [],
      color: "neon-pink",
      icon: "fa-brain"
    }
  ];

  const calculateProgress = (missions: any[]) => {
    if (!missions.length) return 0;
    const completed = missions.filter(m => userStats.completedMissions.includes(m.slug)).length;
    return Math.round((completed / missions.length) * 100);
  };

  const getMissionNodeStatus = (missions: any[]) => {
    const completed = missions.filter(m => userStats.completedMissions.includes(m.slug)).length;
    if (completed === missions.length) return "completed";
    if (completed > 0) return "active";
    if (missions.length === 0 || !missions[0]?.isUnlocked) return "locked";
    return "available";
  };

  if (isLoading) {
    return (
      <div className="pt-24 pb-8 px-8 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <Skeleton className="h-12 w-64 mx-auto mb-4" />
            <Skeleton className="h-6 w-96 mx-auto" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-64 rounded-2xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="pt-24 pb-8 px-8 min-h-screen"
    >
      {/* 3D Background */}
      <div className="fixed inset-0 -z-10">
        <ThreeScene />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Universe Title */}
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="font-orbitron font-bold text-4xl mb-4 neon-text">Universo de Missões</h2>
          <p className="text-gray-400 text-lg">Explore os desafios e construa sua jornada de aprendizado</p>
        </motion.div>
        
        {/* Mission Islands/Planets Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {missionGroups.map((group, index) => {
            const progress = calculateProgress(group.missions);
            const nodeStatus = getMissionNodeStatus(group.missions);
            const completedCount = group.missions.filter(m => userStats.completedMissions.includes(m.slug)).length;

            return (
              <motion.div
                key={group.category}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 + index * 0.1, duration: 0.6 }}
                className="mission-card rounded-2xl p-6 relative overflow-hidden group"
              >
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className={`font-orbitron font-bold text-xl text-${group.color}`}>
                      {group.title}
                    </h3>
                    <div className={`mission-node ${nodeStatus} w-12 h-12 rounded-full flex items-center justify-center ${
                      nodeStatus === 'completed' ? 'bg-gradient-to-r from-cyber-gold to-cyber-orange' :
                      nodeStatus === 'active' ? 'bg-gradient-to-r from-neon-blue to-neon-green' :
                      nodeStatus === 'locked' ? 'bg-gradient-to-r from-gray-600 to-gray-400' :
                      'bg-gradient-to-r from-neon-blue to-neon-green'
                    }`}>
                      <i className={`fas ${
                        nodeStatus === 'completed' ? 'fa-check' :
                        nodeStatus === 'locked' ? 'fa-lock' :
                        'fa-play'
                      } text-dark-navy font-bold`}></i>
                    </div>
                  </div>
                  <p className="text-gray-300 mb-4">{group.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-cyber-gold">
                        {completedCount}/{group.missions.length} Missões
                      </span>
                      <div className="w-20 bg-gray-700 rounded-full h-2">
                        <div 
                          className="progress-bar rounded-full transition-all duration-500" 
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        if (group.missions.length > 0 && nodeStatus !== 'locked') {
                          onOpenMission(group.missions[0].slug);
                        }
                      }}
                      disabled={nodeStatus === 'locked' || group.missions.length === 0}
                      className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                        nodeStatus === 'locked' || group.missions.length === 0
                          ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                          : 'btn-primary hover:scale-105'
                      }`}
                    >
                      {nodeStatus === 'locked' ? 'BLOQUEADO' : 
                       nodeStatus === 'completed' ? 'REVISAR' :
                       nodeStatus === 'active' ? 'CONTINUAR' : 'EXPLORAR'}
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
        
        {/* Recent Achievements */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="floating-ui rounded-2xl p-6 mb-8"
        >
          <h3 className="font-orbitron font-bold text-xl mb-4 text-neon-blue">Conquistas Recentes</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className={`text-center p-4 rounded-xl transition-all ${
              userStats.completedMissions.length > 0 
                ? 'bg-gradient-to-br from-cyber-gold/20 to-cyber-orange/20' 
                : 'bg-gradient-to-br from-gray-600/20 to-gray-400/20 opacity-50'
            }`}>
              <i className="fas fa-trophy text-cyber-gold text-2xl mb-2"></i>
              <p className="text-sm font-semibold">Primeiro Sucesso</p>
            </div>
            <div className={`text-center p-4 rounded-xl transition-all ${
              userStats.completedMissions.filter(m => m.includes('array')).length > 0
                ? 'bg-gradient-to-br from-neon-green/20 to-neon-blue/20'
                : 'bg-gradient-to-br from-gray-600/20 to-gray-400/20 opacity-50'
            }`}>
              <i className="fas fa-code text-neon-green text-2xl mb-2"></i>
              <p className="text-sm font-semibold">Mestre dos Arrays</p>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-neon-pink/20 to-neon-purple/20 rounded-xl opacity-50">
              <i className="fas fa-lightning-bolt text-neon-pink text-2xl mb-2"></i>
              <p className="text-sm font-semibold">Velocidade da Luz</p>
            </div>
            <div className={`text-center p-4 rounded-xl transition-all ${
              userStats.completedMissions.filter(m => m.includes('recursive')).length > 0
                ? 'bg-gradient-to-br from-neon-blue/20 to-neon-purple/20'
                : 'bg-gradient-to-br from-gray-600/20 to-gray-400/20 opacity-50'
            }`}>
              <i className="fas fa-brain text-neon-blue text-2xl mb-2"></i>
              <p className="text-sm font-semibold">Pensador Recursivo</p>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
