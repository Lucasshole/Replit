import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface Notification {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
  duration?: number;
}

export default function NotificationSystem() {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    const handleNotification = (event: CustomEvent) => {
      const notification: Notification = {
        id: Date.now().toString(),
        ...event.detail,
        duration: event.detail.duration || 5000,
      };
      
      setNotifications(prev => [...prev, notification]);
      
      setTimeout(() => {
        setNotifications(prev => prev.filter(n => n.id !== notification.id));
      }, notification.duration);
    };

    window.addEventListener('codequest:notification', handleNotification as EventListener);
    
    return () => {
      window.removeEventListener('codequest:notification', handleNotification as EventListener);
    };
  }, []);

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const getTypeClasses = (type: string) => {
    switch (type) {
      case 'success':
        return 'border-l-4 border-neon-green text-neon-green';
      case 'error':
        return 'border-l-4 border-red-400 text-red-400';
      case 'info':
      default:
        return 'border-l-4 border-neon-blue text-neon-blue';
    }
  };

  return (
    <div className="fixed top-24 right-4 z-50 space-y-2">
      <AnimatePresence>
        {notifications.map((notification) => (
          <motion.div
            key={notification.id}
            initial={{ x: 300, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 300, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className={`floating-ui rounded-lg p-4 min-w-64 ${getTypeClasses(notification.type)}`}
          >
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium flex-1">{notification.message}</span>
              <button
                onClick={() => removeNotification(notification.id)}
                className="text-gray-400 hover:text-white"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

// Helper function to show notifications
export const showNotification = (message: string, type: 'success' | 'error' | 'info' = 'info', duration?: number) => {
  const event = new CustomEvent('codequest:notification', {
    detail: { message, type, duration }
  });
  window.dispatchEvent(event);
};
