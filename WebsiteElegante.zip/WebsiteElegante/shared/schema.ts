import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  xp: integer("xp").notNull().default(0),
  energy: integer("energy").notNull().default(3),
  completedMissions: text("completed_missions").array().notNull().default([]),
  badges: text("badges").array().notNull().default([]),
  preferences: jsonb("preferences").default({}),
});

export const missions = pgTable("missions", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  difficulty: integer("difficulty").notNull(), // 1-5 stars
  xpReward: integer("xp_reward").notNull(),
  category: text("category").notNull(),
  instructions: text("instructions").notNull(),
  examples: jsonb("examples").notNull(),
  restrictions: text("restrictions").array().notNull().default([]),
  starterCode: text("starter_code").notNull(),
  tests: jsonb("tests").notNull(),
  isUnlocked: boolean("is_unlocked").notNull().default(true),
});

export const userMissionProgress = pgTable("user_mission_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  missionSlug: text("mission_slug").notNull(),
  completed: boolean("completed").notNull().default(false),
  attempts: integer("attempts").notNull().default(0),
  bestTime: integer("best_time"), // milliseconds
  lastCode: text("last_code"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  xp: true,
  energy: true,
  completedMissions: true,
  badges: true,
  preferences: true,
});

export const insertMissionSchema = createInsertSchema(missions).omit({
  id: true,
});

export const insertUserMissionProgressSchema = createInsertSchema(userMissionProgress).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Mission = typeof missions.$inferSelect;
export type UserMissionProgress = typeof userMissionProgress.$inferSelect;
export type InsertMission = z.infer<typeof insertMissionSchema>;
export type InsertUserMissionProgress = z.infer<typeof insertUserMissionProgressSchema>;
