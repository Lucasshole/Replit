import { users, missions, userMissionProgress, type User, type InsertUser, type Mission, type InsertMission, type UserMissionProgress, type InsertUserMissionProgress } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  getMission(slug: string): Promise<Mission | undefined>;
  getAllMissions(): Promise<Mission[]>;
  getMissionsByCategory(category: string): Promise<Mission[]>;
  createMission(mission: InsertMission): Promise<Mission>;
  
  getUserProgress(userId: number, missionSlug: string): Promise<UserMissionProgress | undefined>;
  updateUserProgress(userId: number, missionSlug: string, progress: Partial<UserMissionProgress>): Promise<UserMissionProgress>;
  getUserCompletedMissions(userId: number): Promise<UserMissionProgress[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private missions: Map<string, Mission>;
  private userProgress: Map<string, UserMissionProgress>;
  private currentUserId: number;
  private currentProgressId: number;

  constructor() {
    this.users = new Map();
    this.missions = new Map();
    this.userProgress = new Map();
    this.currentUserId = 1;
    this.currentProgressId = 1;
    
    // Initialize with sample missions
    this.initializeMissions();
  }

  private initializeMissions() {
    const sampleMissions: InsertMission[] = [
      {
        slug: "palindrome-basic",
        title: "Desafio do Palíndromo",
        description: "Verifique se uma string é um palíndromo",
        difficulty: 2,
        xpReward: 150,
        category: "arrays",
        instructions: "Escreva uma função que verifica se uma string é um palíndromo (lê-se igual de frente para trás). Ignore espaços, pontuação e diferenças entre maiúsculas e minúsculas.",
        examples: [
          { input: '"arara"', output: "true" },
          { input: '"hello"', output: "false" },
          { input: '"A man a plan a canal Panama"', output: "true" }
        ],
        restrictions: [
          "Ignore espaços e pontuação",
          "Ignore diferenças de maiúscula/minúscula",
          "Não use métodos built-in como reverse()"
        ],
        starterCode: `function isPalindrome(str) {
  // Seu código aqui
  // Dica: Normalize a string primeiro
  // Depois compare caractere por caractere
  
}`,
        tests: [
          { input: "arara", expected: true },
          { input: "hello", expected: false },
          { input: "A man a plan a canal Panama", expected: true },
          { input: "race a car", expected: false },
          { input: "Madam", expected: true }
        ],
        isUnlocked: true
      },
      {
        slug: "fizzbuzz",
        title: "FizzBuzz Classic",
        description: "O clássico problema FizzBuzz",
        difficulty: 1,
        xpReward: 100,
        category: "arrays",
        instructions: "Crie uma função que retorna um array de números de 1 a n, mas substitui múltiplos de 3 por 'Fizz', múltiplos de 5 por 'Buzz', e múltiplos de ambos por 'FizzBuzz'.",
        examples: [
          { input: "15", output: "[1,2,'Fizz',4,'Buzz','Fizz',7,8,'Fizz','Buzz',11,'Fizz',13,14,'FizzBuzz']" }
        ],
        restrictions: [
          "Use condicionais para verificar divisibilidade",
          "Retorne um array"
        ],
        starterCode: `function fizzBuzz(n) {
  // Seu código aqui
  
}`,
        tests: [
          { input: 15, expected: [1,2,"Fizz",4,"Buzz","Fizz",7,8,"Fizz","Buzz",11,"Fizz",13,14,"FizzBuzz"] },
          { input: 5, expected: [1,2,"Fizz",4,"Buzz"] }
        ],
        isUnlocked: true
      },
      {
        slug: "factorial-recursive",
        title: "Fatorial Recursivo",
        description: "Calcule o fatorial usando recursão",
        difficulty: 3,
        xpReward: 200,
        category: "recursion",
        instructions: "Implemente uma função recursiva que calcula o fatorial de um número.",
        examples: [
          { input: "5", output: "120" },
          { input: "0", output: "1" }
        ],
        restrictions: [
          "Use recursão",
          "Trate o caso base corretamente"
        ],
        starterCode: `function factorial(n) {
  // Seu código aqui
  // Lembre-se do caso base!
  
}`,
        tests: [
          { input: 5, expected: 120 },
          { input: 0, expected: 1 },
          { input: 1, expected: 1 },
          { input: 4, expected: 24 }
        ],
        isUnlocked: false
      }
    ];

    sampleMissions.forEach((mission, index) => {
      const missionWithId: Mission = { ...mission, id: index + 1 };
      this.missions.set(mission.slug, missionWithId);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      xp: 0,
      energy: 3,
      completedMissions: [],
      badges: [],
      preferences: {}
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getMission(slug: string): Promise<Mission | undefined> {
    return this.missions.get(slug);
  }

  async getAllMissions(): Promise<Mission[]> {
    return Array.from(this.missions.values());
  }

  async getMissionsByCategory(category: string): Promise<Mission[]> {
    return Array.from(this.missions.values()).filter(mission => mission.category === category);
  }

  async createMission(mission: InsertMission): Promise<Mission> {
    const id = this.missions.size + 1;
    const missionWithId: Mission = { ...mission, id };
    this.missions.set(mission.slug, missionWithId);
    return missionWithId;
  }

  async getUserProgress(userId: number, missionSlug: string): Promise<UserMissionProgress | undefined> {
    const key = `${userId}-${missionSlug}`;
    return this.userProgress.get(key);
  }

  async updateUserProgress(userId: number, missionSlug: string, progress: Partial<UserMissionProgress>): Promise<UserMissionProgress> {
    const key = `${userId}-${missionSlug}`;
    const existing = this.userProgress.get(key);
    
    const updated: UserMissionProgress = {
      id: existing?.id || this.currentProgressId++,
      userId,
      missionSlug,
      completed: false,
      attempts: 0,
      bestTime: null,
      lastCode: null,
      ...existing,
      ...progress
    };
    
    this.userProgress.set(key, updated);
    return updated;
  }

  async getUserCompletedMissions(userId: number): Promise<UserMissionProgress[]> {
    return Array.from(this.userProgress.values()).filter(
      progress => progress.userId === userId && progress.completed
    );
  }
}

export const storage = new MemStorage();
