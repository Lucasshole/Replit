import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

const executeCodeSchema = z.object({
  code: z.string(),
  missionSlug: z.string(),
});

const updateProgressSchema = z.object({
  missionSlug: z.string(),
  completed: z.boolean().optional(),
  attempts: z.number().optional(),
  bestTime: z.number().optional(),
  lastCode: z.string().optional(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all missions
  app.get("/api/missions", async (req, res) => {
    try {
      const missions = await storage.getAllMissions();
      res.json(missions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch missions" });
    }
  });

  // Get missions by category
  app.get("/api/missions/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const missions = await storage.getMissionsByCategory(category);
      res.json(missions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch missions by category" });
    }
  });

  // Get specific mission
  app.get("/api/missions/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const mission = await storage.getMission(slug);
      if (!mission) {
        return res.status(404).json({ message: "Mission not found" });
      }
      res.json(mission);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch mission" });
    }
  });

  // Execute code for a mission
  app.post("/api/missions/:slug/execute", async (req, res) => {
    try {
      const { slug } = req.params;
      const { code } = executeCodeSchema.parse(req.body);
      
      const mission = await storage.getMission(slug);
      if (!mission) {
        return res.status(404).json({ message: "Mission not found" });
      }

      // Simple code execution simulation
      const results = await executeMissionCode(code, mission);
      
      res.json(results);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request body", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to execute code" });
    }
  });

  // Update user progress (mock user ID = 1 for now)
  app.post("/api/progress", async (req, res) => {
    try {
      const userId = 1; // Mock user ID
      const progressData = updateProgressSchema.parse(req.body);
      
      const progress = await storage.updateUserProgress(userId, progressData.missionSlug, progressData);
      
      // If mission completed, update user XP and badges
      if (progressData.completed) {
        const mission = await storage.getMission(progressData.missionSlug);
        if (mission) {
          const user = await storage.getUser(userId);
          if (user) {
            await storage.updateUser(userId, {
              xp: user.xp + mission.xpReward,
              completedMissions: [...user.completedMissions, progressData.missionSlug]
            });
          }
        }
      }
      
      res.json(progress);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request body", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update progress" });
    }
  });

  // Get user progress for a specific mission
  app.get("/api/progress/:missionSlug", async (req, res) => {
    try {
      const userId = 1; // Mock user ID
      const { missionSlug } = req.params;
      
      const progress = await storage.getUserProgress(userId, missionSlug);
      res.json(progress || null);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch progress" });
    }
  });

  // Get user stats
  app.get("/api/user/stats", async (req, res) => {
    try {
      const userId = 1; // Mock user ID
      const user = await storage.getUser(userId);
      
      if (!user) {
        // Create default user if not exists
        const newUser = await storage.createUser({ username: "demo", password: "demo" });
        return res.json({
          xp: newUser.xp,
          energy: newUser.energy,
          completedMissions: newUser.completedMissions,
          badges: newUser.badges
        });
      }
      
      res.json({
        xp: user.xp,
        energy: user.energy,
        completedMissions: user.completedMissions,
        badges: user.badges
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Simple code execution simulation
async function executeMissionCode(code: string, mission: any): Promise<any> {
  try {
    // Basic validation
    if (!code.trim()) {
      return {
        success: false,
        error: "Code is empty",
        tests: mission.tests.map((test: any) => ({
          input: test.input,
          expected: test.expected,
          actual: undefined,
          passed: false
        }))
      };
    }

    // For safety, we'll do a simple pattern matching validation
    // In a real implementation, you'd want to use a sandboxed execution environment
    const functionName = extractFunctionName(code);
    if (!functionName) {
      return {
        success: false,
        error: "No function found in code",
        tests: mission.tests.map((test: any) => ({
          input: test.input,
          expected: test.expected,
          actual: undefined,
          passed: false
        }))
      };
    }

    // Simulate test execution
    const testResults = mission.tests.map((test: any) => {
      // For demo purposes, simulate some logic
      let passed = false;
      let actual = undefined;

      if (mission.slug === "palindrome-basic") {
        actual = simulatePalindromeTest(code, test.input);
        passed = actual === test.expected;
      } else if (mission.slug === "fizzbuzz") {
        actual = simulateFizzBuzzTest(code, test.input);
        passed = JSON.stringify(actual) === JSON.stringify(test.expected);
      } else if (mission.slug === "factorial-recursive") {
        actual = simulateFactorialTest(code, test.input);
        passed = actual === test.expected;
      }

      return {
        input: test.input,
        expected: test.expected,
        actual,
        passed
      };
    });

    const allPassed = testResults.every(test => test.passed);
    const executionTime = Math.floor(Math.random() * 100) + 10; // Simulate execution time

    return {
      success: allPassed,
      tests: testResults,
      executionTime,
      complexity: inferComplexity(code)
    };

  } catch (error) {
    return {
      success: false,
      error: "Code execution failed",
      tests: mission.tests.map((test: any) => ({
        input: test.input,
        expected: test.expected,
        actual: undefined,
        passed: false
      }))
    };
  }
}

function extractFunctionName(code: string): string | null {
  const match = code.match(/function\s+(\w+)/);
  return match ? match[1] : null;
}

function simulatePalindromeTest(code: string, input: string): boolean {
  // Basic simulation - check if code has basic palindrome logic
  const hasNormalization = code.includes("toLowerCase") || code.includes("replace");
  const hasComparison = code.includes("===") || code.includes("==");
  
  if (hasNormalization && hasComparison) {
    const normalized = input.toLowerCase().replace(/[^a-zA-Z0-9]/g, "");
    return normalized === normalized.split("").reverse().join("");
  }
  return false;
}

function simulateFizzBuzzTest(code: string, input: number): any[] {
  const hasFizz = code.includes("Fizz");
  const hasBuzz = code.includes("Buzz");
  const hasModulo = code.includes("%");
  
  if (hasFizz && hasBuzz && hasModulo) {
    const result = [];
    for (let i = 1; i <= input; i++) {
      if (i % 15 === 0) result.push("FizzBuzz");
      else if (i % 3 === 0) result.push("Fizz");
      else if (i % 5 === 0) result.push("Buzz");
      else result.push(i);
    }
    return result;
  }
  return [];
}

function simulateFactorialTest(code: string, input: number): number {
  const hasRecursion = code.includes("factorial") && code.includes("return");
  const hasBaseCase = code.includes("0") || code.includes("1");
  
  if (hasRecursion && hasBaseCase) {
    let result = 1;
    for (let i = 2; i <= input; i++) {
      result *= i;
    }
    return result;
  }
  return 0;
}

function inferComplexity(code: string): string {
  if (code.includes("for") && code.includes("for")) return "O(n²)";
  if (code.includes("for") || code.includes("while")) return "O(n)";
  return "O(1)";
}
